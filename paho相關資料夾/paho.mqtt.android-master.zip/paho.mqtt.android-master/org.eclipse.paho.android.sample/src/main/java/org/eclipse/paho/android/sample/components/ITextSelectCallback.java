package org.eclipse.paho.android.sample.components;


public interface ITextSelectCallback {
    public void onTextUpdate(String updatedText);
}
